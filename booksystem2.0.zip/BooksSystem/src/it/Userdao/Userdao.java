package it.Userdao;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.JDBCutils.JDBCUtils;
import it.login___.Book_Utils;

public class Userdao {
	public static boolean register(HttpServletRequest request, HttpServletResponse response) {
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		try {
			request.setCharacterEncoding("utf-8");
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String gender = request.getParameter("gender");
			String email = request.getParameter("email");
			String phone = request.getParameter("phone");
			String birthday = request.getParameter("birthday");
			conn = JDBCUtils.getconn();
			stat = conn.createStatement();
			String sql = "insert into users(username,passwords,gender,email" + ",phone,birthday) values('" + username
					+ "','" + password + "','" + gender + "','" + email + "','" + phone + "','" + birthday + "')";
			System.out.println(sql);
			int i = stat.executeUpdate(sql);
//			System.out.println(i);
			return true;
		} catch (Exception e) {

			e.printStackTrace();
			return false;
		} finally {
			JDBCUtils.release(rs, stat, conn);
		}
	}

	public static void login(HttpServletRequest request, HttpServletResponse response)
			throws UnsupportedEncodingException {
		request.setCharacterEncoding("utf-8");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		HttpSession session = request.getSession();
		try {
			conn = JDBCUtils.getconn();
			stat = conn.createStatement();
			String sql = "select * from users where username = '" + username + "' and passwords = '" + password + "'";
			rs = stat.executeQuery(sql);
			while (rs.next()) {
				String name = rs.getString("username");
				String psw = rs.getString("passwords");
				if (name.equals(username) && psw.equals(password)) {
					session.setAttribute("name", username);
					response.sendRedirect("/BooksSystem/Book_I_D_U_S?mode=selectall");
					// response.sendRedirect("/BooksSystem/index.jsp");
					return;
				}

			}
			String error = "�˺Ż��������������������";
			session.setAttribute("error", error);
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
