package it.login___;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.Userdao.Userdao;

public class Book_I_D_U_S extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		String s = request.getParameter("mode");
		request.setCharacterEncoding("utf-8");

		if (s.equals("delete")) {
			String id = request.getParameter("id");
			Book_Utils.delete(id);
		} else if (s.equals("update")) {
			String id = request.getParameter("id");
			Book book = Book_Utils.select(id);
			session.setAttribute("book", book);
			request.getRequestDispatcher("update.jsp").forward(request, response);
			return;
		} else if (s.equals("insert")) {
			request.setCharacterEncoding("utf-8");
			String id = request.getParameter("id");
			String name = request.getParameter("name");
			System.out.println(name);
			String pages = request.getParameter("pages");
			String money = request.getParameter("money");
			String date = request.getParameter("date");
			Book_Utils.insert(id, name, pages, money, date);
		}else if(s.equals("book_update")) {
			Book_Utils.book_update(request, response);
			return;
		}
		ArrayList<Book> lis = Book_Utils.selectall();
		session.setAttribute("lis", lis);
		request.getRequestDispatcher("index.jsp").forward(request, response);
		return;
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
