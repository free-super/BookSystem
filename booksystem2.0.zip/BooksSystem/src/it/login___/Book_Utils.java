package it.login___;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.JDBCutils.JDBCUtils;

public class Book_Utils {
	public static ArrayList<Book> selectall() {
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		ArrayList<Book> lis = new ArrayList<Book>();
		try {
			conn = JDBCUtils.getconn();
			stat = conn.createStatement();
			String sql = "select * from books";
			rs = stat.executeQuery(sql);
			while (rs.next()) {
				int b_id = rs.getInt("b_id");
				String b_name = rs.getString("b_name");
				String b_pages = rs.getString("b_pages");
				String b_money = rs.getString("b_money");
				Date b_date = rs.getDate("b_date");
				Book book = new Book(b_id, b_name, b_pages, b_money, b_date);
				lis.add(book);
			}
			return lis;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Book select(String id) {
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		try {
			conn = JDBCUtils.getconn();
			stat = conn.createStatement();
			String sql = "select * from books where b_id = " + id;
			rs = stat.executeQuery(sql);
			while (rs.next()) {
				Book book = new Book(rs.getInt("b_id"), rs.getString("b_name"), rs.getString("b_pages"),
						rs.getString("b_money"), rs.getDate("b_date"));
				return book;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void delete(String id) {
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		// ArrayList<Book> lis = new ArrayList<Book>();
		try {
			conn = JDBCUtils.getconn();
			stat = conn.createStatement();
			String sql = "delete from books where b_id=" + id;
			stat.executeLargeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.release(null, stat, conn);
		}
	}

	public static void update(String id, String name, String pages, String money, String date) {
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		try {
			conn = JDBCUtils.getconn();
			stat = conn.createStatement();
			String sql = "update books set b_name = '" + name + "',b_pages = '" + pages + "',b_money='" + money
					+ "',b_date='" + date + "' where b_id = " + id;
			stat.executeUpdate(sql);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.release(null, stat, conn);
		}
	}

	public static void insert(String id, String name, String pages, String money, String date) {
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		try {
			conn = JDBCUtils.getconn();
			stat = conn.createStatement();
			String sql = "insert into books(b_name,b_pages,b_money,b_date) values('" + name + "','" + pages + "','"
					+ money + "','" + date + "')";
			stat.executeUpdate(sql);
			System.out.println(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.release(null, stat, conn);
		}
	}

	public static void main(String[] args) {
		Book_Utils.insert("5", "���", "265", "25", "2002-5-5");
	}

	public static void book_update(HttpServletRequest request, HttpServletResponse response)
			throws UnsupportedEncodingException, ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String pages = request.getParameter("pages");
		String money = request.getParameter("money");
		String date = request.getParameter("date");
		Book_Utils.update(id, name, pages, money, date);
		request.getRequestDispatcher("/Book_I_D_U_S?mode=selectall").forward(request, response);
		return;
	}
}
