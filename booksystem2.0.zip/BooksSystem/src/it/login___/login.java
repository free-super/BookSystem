package it.login___;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.Userdao.Userdao;

public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String mode = request.getParameter("mode");
		System.out.println(mode);
		if (mode.equals("register")) {
			Userdao.register(request, response);
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		if(mode.equals("login")) {
			Userdao.login(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
