package it.login___;

import java.util.Date;

public class Book {
	private int b_id;
	private String b_name;
	private String b_pages;
	private String b_money;
	private Date b_date;

	public int getB_id() {
		return b_id;
	}

	public void setB_id(int b_id) {
		this.b_id = b_id;
	}

	public String getB_name() {
		return b_name;
	}

	public void setB_name(String b_name) {
		this.b_name = b_name;
	}

	public String getB_pages() {
		return b_pages;
	}

	public void setB_pages(String b_pages) {
		this.b_pages = b_pages;
	}

	public String getB_money() {
		return b_money;
	}

	public void setB_money(String b_money) {
		this.b_money = b_money;
	}

	public Date getB_date() {
		return b_date;
	}

	public void setB_date(Date b_date) {
		this.b_date = b_date;
	}

	public Book(int b_id, String b_name, String b_pages, String b_money, Date b_date) {

		this.b_id = b_id;
		this.b_name = b_name;
		this.b_pages = b_pages;
		this.b_money = b_money;
		this.b_date = b_date;
	}

	public Book() {

	}

	@Override
	public String toString() {
		return "Book [b_id=" + b_id + ", b_name=" + b_name + ", b_pages=" + b_pages + ", b_money=" + b_money
				+ ", b_date=" + b_date + "]";
	}

}
